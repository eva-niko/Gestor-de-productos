# Crear archivo ejecutable
pip install pyinstaller
pyinstaller --onefile menu.py 
