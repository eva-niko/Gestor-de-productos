CREATE TABLE IF NOT EXISTS productos (
    "id" INTEGER,
    "nombre" TEXT NOT NULL,
    "marca" TEXT NOT NULL,
    "cantidad" INTEGER NOT NULL,
    PRIMARY KEY("id") 
);